/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sonaglichristiancontocorrente;

/**
 *
 * @author sonagli.christian
 */
public class InfoUtente {
    public String nome;
    public String cognome;
    public double conto;
    
    /**
     * 
     * @param nome nome dell'utente
     * @param cognome cognome dell'utente
     * @param conto conto dell'utente
     */
    public InfoUtente(String nome, String cognome, double conto)
    {
        this.nome = nome;
        this.cognome = cognome;
        this.conto = conto;
    }
    /**
     * 
     * @return restituisce il nome dell'utente
     */
    public String getNome()
    {
        return nome;
    }
    /**
     * 
     * @return restituisce il cognome dell'utente
     */
        public String getCognome()
    {
        return cognome;
    }
      /**
       * 
       * @return restituisce il conto dell'utente
       */  
        public double getConto()
    {
        return conto;
    }

    /**
     * 
     * @return restituisce le info del conto (nome, cognome, conto)
     */
    public String toString()
    {
        return "Nome: " + nome + " " + " Cognome: " + cognome + " " + " Conto: " + conto;
    }
    
}
