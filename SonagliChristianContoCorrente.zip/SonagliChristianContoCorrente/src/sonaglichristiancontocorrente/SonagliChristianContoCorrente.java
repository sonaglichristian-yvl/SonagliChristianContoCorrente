/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sonaglichristiancontocorrente;
import java.util.Scanner;
/**
 *
 * @author sonagli.christian
 */
public class SonagliChristianContoCorrente {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      
         
        ContoCorrente CC;
        InfoUtente INFO;
        
        String nome = "Christian";
        String cognome = "Sonagli";
        double conto = 1000;
        
        INFO = new InfoUtente(nome, cognome, conto);
        CC = new ContoCorrente(INFO);
        
        System.out.println("Nome: " + INFO.getNome());
        System.out.println("Cognome: " + INFO.getCognome());
        System.out.println("Conto: " + INFO.getConto());
        
        int n = 0;
        int i;
        while (n == 0)
        {
            System.out.print("\nOPZIONI");
            System.out.print("\n1|Preleva");
            System.out.print("\n2|Versa");
            System.out.print("\n3|Info utente");
            System.out.print("\n4|Esci\n");
            Scanner scan = new Scanner(System.in);
            i = scan.nextInt();
            
            switch(i)
                    {
                        case 1:
                            System.out.print("Inserisci l'importo da prelevare: ");
                            double prel = scan.nextDouble();
                            if (prel <= INFO.conto)
                            {
                                CC.prelievo(prel);
                                System.out.print("Prelievo effettuato!");
                            }
                            break;
                        case 2:
                            System.out.print("Inserisci l'importo da versare: ");
                            double vers = scan.nextDouble();
                            CC.versamento(vers);
                            System.out.print("Versamento effettuato!");
                            break;
                        case 3:
                            System.out.print(INFO.toString());
                            break;
                        case 4:
                            System.out.print("Esco...");
                            n++;
                            break;
                        default:
                            System.out.print("Non valido!");
                            break;
                    }
        }
        
        
        
    }
    
}
