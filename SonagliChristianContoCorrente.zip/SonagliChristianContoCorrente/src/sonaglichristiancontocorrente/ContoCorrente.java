/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this templates
 */
package sonaglichristiancontocorrente;

/**
 *
 * @author sonagli.christian
 */
public class ContoCorrente {
    
   private InfoUtente info;
   
   /**
    * 
    * @param info classe InfoUtente
    */
   public ContoCorrente(InfoUtente info)
   {
       this.info = info;
   }
    /**
     * 
     * @param versamento attributo con valore inserito dall'utente per fare il versamento
     */
   public void versamento(double versamento)
   {
       info.conto = info.conto + versamento;
   }
   /**
    * 
    * @param prelievo attributo con valore inserito dall'utente per fare il prelievo 
    */
   public void prelievo(double prelievo)
   {
       if (prelievo <= info.conto)
       {
           info.conto = info.conto - prelievo;
       }
   }
   

   
}
